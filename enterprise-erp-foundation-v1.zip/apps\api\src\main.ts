import 'dotenv/config';
import http from 'node:http';
import { URL } from 'node:url';
import { ERP_MODULES_CATALOG, ErpModuleCode, TenantExecutionContext } from '@delta-erp/shared';
import { PrismaService } from './infrastructure/database/prisma.service';
import { AuditService } from './core/audit/audit.service';
import { FinancialModule } from './modules/financial/financial.module';

const PORT = Number(process.env.PORT || process.env.API_PORT || 3000);
const prisma = new PrismaService();
const auditService = new AuditService(prisma);
const financialModule = new FinancialModule(prisma, auditService);

const OPENAPI_SPEC = {
  openapi: '3.0.3',
  info: {
    title: 'ENTERPRISE ERP (DELTA ERP) — API Gateway & Core v1.0',
    version: '1.0.0',
    description:
      'API Central do Monólito Modular + DDD. Suporta Isolamento Multiempresa (Tenant & Company), RBAC + ABAC, Auditoria Imutável, Transactional Outbox e os 20 Módulos Empresariais.',
  },
  servers: [{ url: `http://localhost:${PORT}`, description: 'Ambiente de Desenvolvimento Local' }],
  tags: [
    { name: 'Core Health', description: 'Monitoramento e conectividade com PostgreSQL e Redis' },
    { name: 'Core Governance', description: 'Multiempresa, Módulos Ativos, RBAC/ABAC e Auditoria' },
    { name: '02. Financial', description: 'Contas a Pagar, Alçadas de Aprovação e Liquidação' },
  ],
  paths: {
    '/api/health': {
      get: {
        tags: ['Core Health'],
        summary: 'Health check completo da API, Prisma e PostgreSQL',
        responses: {
          '200': {
            description: 'Sistema operacional e conectado ao banco de dados',
          },
        },
      },
    },
    '/api/foundation/overview': {
      get: {
        tags: ['Core Governance'],
        summary: 'Retorna visão consolidada da fundação: empresas, módulos, perfis RBAC/ABAC, títulos e auditoria',
        parameters: [
          {
            name: 'companyCode',
            in: 'query',
            required: false,
            schema: { type: 'string', default: 'EMP-01' },
            description: 'Código da empresa ativa (ex: EMP-01 Matriz ou EMP-02 Eventos)',
          },
        ],
        responses: {
          '200': { description: 'Estado atual da fundação carregado do PostgreSQL' },
        },
      },
    },
    '/api/financial/payables': {
      post: {
        tags: ['02. Financial'],
        summary: 'Cria um novo título em Contas a Pagar com validação de domínio, Workflow e AuditLog',
        responses: {
          '201': { description: 'Título criado e enviado para fila de alçada (Workflow)' },
        },
      },
    },
    '/api/financial/payables/{id}/approve': {
      post: {
        tags: ['02. Financial'],
        summary: 'Aprova um título a pagar validando alçada ABAC do perfil e publicando no Outbox',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          '200': { description: 'Título aprovado com sucesso' },
          '403': { description: 'Valor excede a alçada de aprovação do perfil' },
        },
      },
    },
  },
};

const SWAGGER_HTML = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>ENTERPRISE ERP — Documentação da API (Swagger)</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.17.14/swagger-ui.css" />
  <style>
    body { margin: 0; background: #F8FAFC; font-family: Inter, system-ui, sans-serif; }
    .topbar { background: #0F172A !important; padding: 12px 24px !important; }
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5.17.14/swagger-ui-bundle.js"></script>
  <script>
    window.onload = () => {
      SwaggerUIBundle({
        url: '/api/openapi.json',
        dom_id: '#swagger-ui',
        deepLinking: true,
        docExpansion: 'list'
      });
    };
  </script>
</body>
</html>`;

function sendJson(res: http.ServerResponse, statusCode: number, payload: unknown) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Tenant-Id, X-Company-Id, Idempotency-Key',
  });
  res.end(JSON.stringify(payload, null, 2));
}

async function readJsonBody(req: http.IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => (raw += chunk));
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    sendJson(res, 204, {});
    return;
  }

  const reqUrl = new URL(req.url || '/', `http://localhost:${PORT}`);
  const pathname = reqUrl.pathname;

  try {
    // 1. Swagger UI (/api/docs) & OpenAPI JSON (/api/openapi.json)
    if (req.method === 'GET' && (pathname === '/api/docs' || pathname === '/api/docs/')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(SWAGGER_HTML);
      return;
    }

    if (req.method === 'GET' && pathname === '/api/openapi.json') {
      sendJson(res, 200, OPENAPI_SPEC);
      return;
    }

    // 2. Health Check (/api/health)
    if (req.method === 'GET' && pathname === '/api/health') {
      const startedAt = Date.now();
      const [tenantsCount, companiesCount, activeModulesCount] = await Promise.all([
        prisma.tenant.count(),
        prisma.company.count(),
        prisma.tenantModuleSubscription.count({ where: { isEnabled: true } }),
      ]);
      const dbLatencyMs = Date.now() - startedAt;

      sendJson(res, 200, {
        status: 'ok',
        service: 'enterprise-erp-api',
        version: '1.0.0',
        architecture: 'Modular Monolith + DDD',
        timestamp: new Date().toISOString(),
        checks: {
          database: {
            status: 'up',
            engine: 'PostgreSQL + Prisma ORM',
            latencyMs: dbLatencyMs,
            tenantsCount,
            companiesCount,
            activeModulesCount,
          },
          cacheAndQueues: {
            status: 'ready',
            engine: 'Redis / BullMQ + Transactional Outbox',
          },
          security: {
            status: 'enforced',
            features: ['RBAC', 'ABAC', 'MFA-Ready', 'Tenant-RLS', 'Immutable-AuditLog'],
          },
        },
      });
      return;
    }

    // 3. Foundation Overview (/api/foundation/overview)
    if (req.method === 'GET' && pathname === '/api/foundation/overview') {
      const companyCode = reqUrl.searchParams.get('companyCode') || 'EMP-01';

      const tenant = await prisma.tenant.findFirst({
        include: {
          companies: {
            orderBy: { code: 'asc' },
          },
          roles: {
            orderBy: { maxApprovalAmount: 'desc' },
          },
          users: {
            include: {
              companyAccesses: {
                include: { company: true, role: true },
              },
            },
          },
        },
      });

      if (!tenant) {
        sendJson(res, 404, { success: false, message: 'Tenant não encontrado. Execute npm run db:seed.' });
        return;
      }

      const activeCompany =
        tenant.companies.find((c) => c.code === companyCode) || tenant.companies[0];

      const [
        costCenters,
        chartOfAccounts,
        categories,
        payables,
        auditLogs,
        outboxEvents,
        workflows,
        eventsList,
      ] = await Promise.all([
        prisma.costCenter.findMany({ where: { companyId: activeCompany.id } }),
        prisma.chartOfAccount.findMany({ where: { companyId: activeCompany.id }, orderBy: { code: 'asc' } }),
        prisma.financialCategory.findMany({ where: { companyId: activeCompany.id } }),
        prisma.accountPayable.findMany({
          where: { companyId: activeCompany.id },
          include: { category: true, costCenter: true },
          orderBy: { createdAt: 'desc' },
          take: 15,
        }),
        prisma.auditLog.findMany({
          where: { tenantId: tenant.id },
          include: { user: true },
          orderBy: { occurredAt: 'desc' },
          take: 12,
        }),
        prisma.outboxEvent.findMany({
          where: { tenantId: tenant.id },
          orderBy: { occurredAt: 'desc' },
          take: 10,
        }),
        prisma.workflowInstance.findMany({
          where: { companyId: activeCompany.id },
          orderBy: { createdAt: 'desc' },
          take: 10,
        }),
        prisma.event.findMany({
          where: { tenantId: tenant.id },
          include: { producer: true, ticketBatches: true },
        }),
      ]);

      sendJson(res, 200, {
        success: true,
        data: {
          tenant: {
            id: tenant.id,
            name: tenant.name,
            slug: tenant.slug,
            planTier: tenant.planTier,
          },
          companies: tenant.companies,
          activeCompany,
          roles: tenant.roles.map((r) => ({
            ...r,
            maxApprovalAmount: Number(r.maxApprovalAmount),
          })),
          users: tenant.users,
          modulesCatalog: ERP_MODULES_CATALOG,
          costCenters,
          chartOfAccounts,
          categories,
          payables: payables.map((p) => ({
            ...p,
            grossAmount: Number(p.grossAmount),
            discountAmount: Number(p.discountAmount),
            taxRetainedAmount: Number(p.taxRetainedAmount),
            netAmount: Number(p.netAmount),
            paidAmount: Number(p.paidAmount),
          })),
          auditLogs,
          outboxEvents,
          workflows: workflows.map((w) => ({
            ...w,
            referenceAmount: Number(w.referenceAmount),
          })),
          eventsList: eventsList.map((e) => ({
            ...e,
            serviceFeePct: Number(e.serviceFeePct),
            grossTicketSales: Number(e.grossTicketSales),
            totalServiceFees: Number(e.totalServiceFees),
            totalPaidOut: Number(e.totalPaidOut),
          })),
        },
      });
      return;
    }

    // 4. Criar Conta a Pagar de Teste Integrado (POST /api/financial/payables)
    if (req.method === 'POST' && pathname === '/api/financial/payables') {
      const body = await readJsonBody(req);
      const tenant = await prisma.tenant.findFirst();
      const company = await prisma.company.findFirst({
        where: { tenantId: tenant?.id, code: body.companyCode || 'EMP-01' },
      });
      const adminUser = await prisma.user.findFirst({ where: { tenantId: tenant?.id } });

      if (!tenant || !company || !adminUser) {
        sendJson(res, 400, { success: false, message: 'Dados base da empresa não encontrados.' });
        return;
      }

      let category = await prisma.financialCategory.findFirst({ where: { companyId: company.id } });
      if (!category) {
        category = await prisma.financialCategory.create({
          data: {
            tenantId: tenant.id,
            companyId: company.id,
            code: 'DESP-TI-01',
            name: 'Infraestrutura Cloud & Licenças Enterprise',
            nature: 'EXPENSE',
          },
        });
      }

      const context: TenantExecutionContext = {
        requestId: `req_${Date.now()}`,
        tenantId: tenant.id,
        companyId: company.id,
        userId: adminUser.id,
        userEmail: adminUser.email,
        userType: 'INTERNAL',
        roleCode: body.roleCode || 'SUPER_ADMIN',
        permissions: ['financial:payable:create', 'financial:payable:approve', 'financial:payable:read'],
        maxApprovalAmount: body.roleCode === 'FINANCIAL_MANAGER' ? 50000 : 999999999,
        allowedCostCenterIds: [],
        ipAddress: req.socket.remoteAddress || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Enterprise-ERP-Client',
      };

      const today = new Date().toISOString().slice(0, 10);
      const created = await financialModule.controller.createPayable(context, {
        categoryId: category.id,
        supplierName: body.supplierName || 'AWS Cloud Services Brasil Ltda',
        supplierTaxId: body.supplierTaxId || '23.456.789/0001-12',
        documentNumber: body.documentNumber || `NF-${Math.floor(10000 + Math.random() * 90000)}`,
        description: body.description || 'Cluster Kubernetes & Banco de Dados Produção',
        issueDate: today,
        dueDate: today,
        competenceDate: today,
        grossAmount: Number(body.grossAmount || 18500),
        discountAmount: Number(body.discountAmount || 0),
        taxRetainedAmount: Number(body.taxRetainedAmount || 850),
        idempotencyKey: `idem_pay_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      });

      sendJson(res, 201, { success: true, data: created });
      return;
    }

    // 5. Aprovar Conta a Pagar com validação ABAC (POST /api/financial/payables/:id/approve)
    const approveMatch = pathname.match(/^\/api\/financial\/payables\/([^/]+)\/approve$/);
    if (req.method === 'POST' && approveMatch) {
      const payableId = approveMatch[1];
      const body = await readJsonBody(req);
      const payable = await prisma.accountPayable.findUnique({ where: { id: payableId } });

      if (!payable) {
        sendJson(res, 404, { success: false, message: 'Título não encontrado.' });
        return;
      }

      const adminUser = await prisma.user.findFirst({ where: { tenantId: payable.tenantId } });
      const roleCode = body.roleCode || 'SUPER_ADMIN';
      const maxApprovalAmount = roleCode === 'FINANCIAL_MANAGER' ? 50000 : 999999999;

      const context: TenantExecutionContext = {
        requestId: `req_apr_${Date.now()}`,
        tenantId: payable.tenantId,
        companyId: payable.companyId,
        userId: adminUser!.id,
        userEmail: adminUser!.email,
        userType: 'INTERNAL',
        roleCode,
        permissions: ['financial:payable:approve'],
        maxApprovalAmount,
        allowedCostCenterIds: [],
        ipAddress: req.socket.remoteAddress || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Enterprise-ERP-Client',
      };

      const approved = await financialModule.controller.approvePayable(context, payableId);
      await auditService.record({
        context,
        moduleCode: ErpModuleCode.FINANCIAL,
        entityName: 'AccountPayable',
        entityId: payable.id,
        action: 'APPROVE',
        previousValues: { status: payable.status },
        newValues: { status: 'APPROVED', approvedByRole: roleCode },
      });

      sendJson(res, 200, { success: true, data: approved });
      return;
    }

    sendJson(res, 404, {
      success: false,
      error: {
        code: 'ROUTE_NOT_FOUND',
        message: `Rota ${req.method} ${pathname} não encontrada. Consulte /api/docs ou /api/health.`,
      },
    });
  } catch (err: any) {
    const isForbidden =
      err?.message?.includes('FORBIDDEN') || err?.message?.includes('LIMIT_EXCEEDED');
    sendJson(res, isForbidden ? 403 : 400, {
      success: false,
      error: {
        code: isForbidden ? 'SECURITY_POLICY_REJECTION' : 'DOMAIN_VALIDATION_ERROR',
        message: err?.message || 'Erro interno no processamento da requisição.',
      },
    });
  }
});

server.listen(PORT, () => {
  console.log(`✅ [ENTERPRISE ERP API] Online em http://localhost:${PORT}/api`);
  console.log(`🩺 [Health Check]       http://localhost:${PORT}/api/health`);
  console.log(`📚 [Swagger API Docs]   http://localhost:${PORT}/api/docs`);
});
