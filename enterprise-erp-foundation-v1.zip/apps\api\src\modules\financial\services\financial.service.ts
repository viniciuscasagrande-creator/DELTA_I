import { ErpModuleCode, roundCurrency, TenantExecutionContext } from '@delta-erp/shared';
import { PrismaService } from '../../../infrastructure/database/prisma.service';
import { AuditService } from '../../../core/audit/audit.service';
import { CoreSecurityPolicy } from '../../../core/permissions/permission.guard';
import { CreateAccountPayableDto, SettleAccountPayableDto } from '../dto/account-payable.dto';
import { AccountPayableEntity } from '../entities/account-payable.entity';
import { FinancialApprovalPolicy } from '../policies/financial-approval.policy';
import { FinancialPayableValidator } from '../validators/financial-payable.validator';

/**
 * Módulo 02: Financeiro — FinancialService
 * Coordena criação, aprovação por alçada ABAC, baixa bancária atômica,
 * registro de auditoria imutável e publicação de evento no Transactional Outbox
 * para integração automática com o Módulo 03 (Contabilidade).
 */
export class FinancialService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly auditService: AuditService
  ) {}

  async createPayable(context: TenantExecutionContext, dto: CreateAccountPayableDto) {
    CoreSecurityPolicy.assertPermissionAndScope(context, 'financial:payable:create', dto.costCenterId);
    FinancialPayableValidator.validateCreateDto(dto);

    const discount = dto.discountAmount ?? 0;
    const interest = dto.interestAmount ?? 0;
    const taxRetained = dto.taxRetainedAmount ?? 0;

    const domainEntity = new AccountPayableEntity({
      id: 'new',
      tenantId: context.tenantId,
      companyId: context.companyId,
      categoryId: dto.categoryId,
      costCenterId: dto.costCenterId,
      supplierName: dto.supplierName,
      supplierTaxId: dto.supplierTaxId,
      documentNumber: dto.documentNumber,
      description: dto.description,
      grossAmount: dto.grossAmount,
      discountAmount: discount,
      interestAmount: interest,
      taxRetainedAmount: taxRetained,
      paidAmount: 0,
      status: 'PENDING_APPROVAL',
    });

    return this.prisma.executeInTenantTransaction(context.tenantId, context.companyId, async (tx) => {
      const created = await tx.accountPayable.create({
        data: {
          tenantId: context.tenantId,
          companyId: context.companyId,
          branchId: context.branchId,
          categoryId: dto.categoryId,
          costCenterId: dto.costCenterId,
          supplierName: dto.supplierName,
          supplierTaxId: dto.supplierTaxId,
          documentNumber: dto.documentNumber,
          description: dto.description,
          originModule: (dto.originModule ?? ErpModuleCode.FINANCIAL) as any,
          originReferenceId: dto.originReferenceId,
          issueDate: new Date(dto.issueDate),
          dueDate: new Date(dto.dueDate),
          competenceDate: new Date(dto.competenceDate),
          grossAmount: dto.grossAmount,
          discountAmount: discount,
          interestAmount: interest,
          taxRetainedAmount: taxRetained,
          netAmount: domainEntity.netAmount,
          paidAmount: 0,
          status: 'PENDING_APPROVAL',
          idempotencyKey: dto.idempotencyKey,
          createdById: context.userId,
        },
      });

      // Cria instância no Motor de Workflow (Módulo 17)
      await tx.workflowInstance.create({
        data: {
          tenantId: context.tenantId,
          companyId: context.companyId,
          moduleCode: 'FINANCIAL',
          entityType: 'ACCOUNT_PAYABLE',
          entityId: created.id,
          referenceAmount: domainEntity.netAmount,
          status: 'PENDING',
          requestedById: context.userId,
        },
      });

      await this.auditService.record({
        context,
        moduleCode: ErpModuleCode.FINANCIAL,
        entityName: 'AccountPayable',
        entityId: created.id,
        action: 'CREATE',
        previousValues: null,
        newValues: {
          documentNumber: created.documentNumber,
          netAmount: Number(created.netAmount),
          status: created.status,
        },
      });

      return created;
    });
  }

  async approvePayable(context: TenantExecutionContext, payableId: string) {
    return this.prisma.executeInTenantTransaction(context.tenantId, context.companyId, async (tx) => {
      const payable = await tx.accountPayable.findFirst({
        where: { id: payableId, tenantId: context.tenantId, companyId: context.companyId },
      });

      if (!payable) {
        throw new Error('PAYABLE_NOT_FOUND_OR_CROSS_COMPANY: Título não encontrado na empresa ativa.');
      }

      const netAmount = Number(payable.netAmount);
      FinancialApprovalPolicy.assertCanApprovePayable(context, netAmount, payable.costCenterId);

      const updated = await tx.accountPayable.update({
        where: { id: payable.id },
        data: {
          status: 'APPROVED',
          approvedById: context.userId,
          approvedAt: new Date(),
        },
      });

      await tx.outboxEvent.create({
        data: {
          tenantId: context.tenantId,
          companyId: context.companyId,
          aggregateType: 'AccountPayable',
          aggregateId: payable.id,
          eventType: 'financial.payable.approved',
          payload: {
            payableId: payable.id,
            netAmount,
            approvedById: context.userId,
          },
        },
      });

      return updated;
    });
  }

  async settlePayable(context: TenantExecutionContext, dto: SettleAccountPayableDto) {
    CoreSecurityPolicy.assertPermissionAndScope(context, 'financial:settlement:execute');

    return this.prisma.executeInTenantTransaction(context.tenantId, context.companyId, async (tx) => {
      const payable = await tx.accountPayable.findFirst({
        where: { id: dto.payableId, tenantId: context.tenantId, companyId: context.companyId },
      });

      if (!payable) {
        throw new Error('PAYABLE_NOT_FOUND: Título a pagar não encontrado na empresa ativa.');
      }

      const entity = new AccountPayableEntity({
        id: payable.id,
        tenantId: payable.tenantId,
        companyId: payable.companyId,
        categoryId: payable.categoryId,
        costCenterId: payable.costCenterId,
        supplierName: payable.supplierName,
        supplierTaxId: payable.supplierTaxId,
        documentNumber: payable.documentNumber,
        description: payable.description,
        grossAmount: Number(payable.grossAmount),
        discountAmount: Number(payable.discountAmount),
        interestAmount: Number(payable.interestAmount),
        taxRetainedAmount: Number(payable.taxRetainedAmount),
        paidAmount: Number(payable.paidAmount),
        status: payable.status as any,
      });

      if (!entity.canBeSettled(dto.amount)) {
        throw new Error(
          `INVALID_SETTLEMENT_STATE: Título com status "${payable.status}" ou valor superior ao saldo em aberto (R$ ${entity.remainingBalance.toFixed(2)}).`
        );
      }

      const newPaidAmount = roundCurrency(Number(payable.paidAmount) + dto.amount);
      const newStatus = newPaidAmount >= entity.netAmount ? 'PAID' : 'PARTIALLY_PAID';

      const transaction = await tx.financialTransaction.create({
        data: {
          tenantId: context.tenantId,
          companyId: context.companyId,
          bankAccountId: dto.bankAccountId,
          payableId: payable.id,
          type: 'DEBIT',
          amount: dto.amount,
          paymentMethod: dto.paymentMethod,
          externalBankRef: dto.externalBankRef,
          notes: dto.notes,
          idempotencyKey: dto.idempotencyKey,
          createdById: context.userId,
        },
      });

      await tx.bankAccount.update({
        where: { id: dto.bankAccountId },
        data: {
          currentBalance: {
            decrement: dto.amount,
          },
        },
      });

      const updatedPayable = await tx.accountPayable.update({
        where: { id: payable.id },
        data: {
          paidAmount: newPaidAmount,
          status: newStatus,
        },
      });

      // Publica evento no Transactional Outbox para o Módulo 03 (Contabilidade) gerar o lançamento de partidas dobradas
      await tx.outboxEvent.create({
        data: {
          tenantId: context.tenantId,
          companyId: context.companyId,
          aggregateType: 'AccountPayable',
          aggregateId: payable.id,
          eventType: 'financial.payable.settled',
          payload: {
            payableId: payable.id,
            transactionId: transaction.id,
            bankAccountId: dto.bankAccountId,
            settledAmount: dto.amount,
            newStatus,
            categoryId: payable.categoryId,
            costCenterId: payable.costCenterId,
          },
        },
      });

      return { payable: updatedPayable, transaction };
    });
  }
}
