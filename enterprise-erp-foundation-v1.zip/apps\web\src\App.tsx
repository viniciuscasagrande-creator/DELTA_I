import React, { useEffect, useState, useCallback } from 'react';
import { formatBRL } from '@delta-erp/shared';

const API_BASE = 'http://localhost:3000/api';

type ActiveTab = 'foundation' | 'modules' | 'financial' | 'audit';

export function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('foundation');
  const [selectedCompanyCode, setSelectedCompanyCode] = useState<string>('EMP-01');
  const [selectedRoleCode, setSelectedRoleCode] = useState<string>('FINANCIAL_MANAGER');
  const [health, setHealth] = useState<any>(null);
  const [overview, setOverview] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Formulário de teste de criação de título financeiro integrado ao Core
  const [supplierName, setSupplierName] = useState('Oracle Cloud Infrastructure Brasil');
  const [grossAmount, setGrossAmount] = useState('32500');

  const fetchDashboardData = useCallback(async (companyCode: string) => {
    setLoading(true);
    try {
      const [healthRes, overviewRes] = await Promise.all([
        fetch(`${API_BASE}/health`),
        fetch(`${API_BASE}/foundation/overview?companyCode=${companyCode}`),
      ]);
      const healthJson = await healthRes.json();
      const overviewJson = await overviewRes.json();
      setHealth(healthJson);
      if (overviewJson.success) {
        setOverview(overviewJson.data);
      }
    } catch (err: any) {
      setActionMessage({
        type: 'error',
        text: `Erro ao conectar na API em ${API_BASE}: ${err?.message || 'Verifique se a API está ativa'}`,
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData(selectedCompanyCode);
  }, [selectedCompanyCode, fetchDashboardData]);

  const handleCreatePayable = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionMessage(null);
    try {
      const res = await fetch(`${API_BASE}/financial/payables`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyCode: selectedCompanyCode,
          roleCode: selectedRoleCode,
          supplierName,
          supplierTaxId: '18.765.432/0001-99',
          description: `Provisão Contábil/Financeira (${selectedCompanyCode})`,
          grossAmount: Number(grossAmount),
          taxRetainedAmount: Math.round(Number(grossAmount) * 0.0465 * 100) / 100,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error?.message || 'Falha ao criar título');
      }
      setActionMessage({
        type: 'success',
        text: `Título ${json.data.documentNumber} criado com sucesso! Workflow de aprovação e AuditLog registrados no PostgreSQL.`,
      });
      fetchDashboardData(selectedCompanyCode);
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err.message });
    }
  };

  const handleApprovePayable = async (payableId: string) => {
    setActionMessage(null);
    try {
      const res = await fetch(`${API_BASE}/financial/payables/${payableId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roleCode: selectedRoleCode }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error?.message || 'Falha na aprovação');
      }
      setActionMessage({
        type: 'success',
        text: `Título aprovado pelo perfil ${selectedRoleCode}! Evento publicado no Transactional Outbox.`,
      });
      fetchDashboardData(selectedCompanyCode);
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err.message });
    }
  };

  const checklistItems = [
    { label: 'Node.js e npm instalados (Node v24+ / npm v11+)', ok: true },
    { label: 'Banco PostgreSQL online e conectado', ok: health?.checks?.database?.status === 'up' },
    { label: 'Dependências do Monorepo instaladas sem erros', ok: true },
    { label: 'Prisma Client gerado (@prisma/client)', ok: Boolean(overview?.tenant?.id) },
    { label: 'Migration inicial (initial_foundation) aplicada', ok: Boolean(overview?.companies?.length) },
    { label: 'API respondendo em /api/health', ok: health?.status === 'ok' },
    { label: 'Dashboard React abrindo no navegador (:5173)', ok: true },
    { label: 'Documentação Swagger acessível em /api/docs', ok: health?.status === 'ok' },
  ];

  const completedChecks = checklistItems.filter((i) => i.ok).length;

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] text-slate-900">
      {/* Sidebar Esquerda — Azul Institucional & Minimalista */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0">
        <div>
          <div className="p-6 border-b border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-700 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              Δ
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-slate-900 tracking-tight text-base">ENTERPRISE ERP</h1>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                  v1.0
                </span>
              </div>
              <p className="text-xs text-slate-500">Fundação Técnica • Monólito DDD</p>
            </div>
          </div>

          <div className="p-4">
            <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Navegação da Fundação
            </p>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveTab('foundation')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                  activeTab === 'foundation'
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>01. Validação & Core ERP</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-white/20 font-mono">
                  {completedChecks}/8
                </span>
              </button>

              <button
                onClick={() => setActiveTab('modules')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                  activeTab === 'modules'
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>02. Catálogo 20 Módulos</span>
                <span className="text-xs opacity-80 font-mono">20+EXT</span>
              </button>

              <button
                onClick={() => setActiveTab('financial')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                  activeTab === 'financial'
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>03. Motor Financeiro & ABAC</span>
                <span className="text-xs opacity-80 font-mono">
                  {overview?.payables?.length ?? 0}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${
                  activeTab === 'audit'
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span>04. Auditoria & Outbox</span>
                <span className="text-xs opacity-80 font-mono">
                  {overview?.auditLogs?.length ?? 0}
                </span>
              </button>
            </nav>
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 space-y-2">
          <a
            href="http://localhost:3000/api/docs"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-blue-50 text-xs font-medium text-slate-700 hover:text-blue-700 border border-slate-200 transition"
          >
            <span>📚 Abrir Swagger (/api/docs)</span>
            <span>↗</span>
          </a>
          <a
            href="http://localhost:3000/api/health"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 text-xs font-medium text-slate-700 hover:text-emerald-700 border border-slate-200 transition"
          >
            <span>🩺 Health Check (/api/health)</span>
            <span className="font-mono text-emerald-600">
              {health?.checks?.database?.latencyMs ? `${health.checks.database.latencyMs}ms` : 'OK'}
            </span>
          </a>
        </div>
      </aside>

      {/* Área Principal */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar Contextual Multiempresa e Simulador RBAC/ABAC */}
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              PostgreSQL Conectado
            </span>
            <span className="text-xs text-slate-500">
              Organização: <strong className="text-slate-800">{overview?.tenant?.name || 'Carregando...'}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Seletor de Perfil RBAC/ABAC */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-500">Perfil Ativo (ABAC):</label>
              <select
                value={selectedRoleCode}
                onChange={(e) => setSelectedRoleCode(e.target.value)}
                className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-slate-800 focus:outline-none focus:border-blue-600"
              >
                <option value="FINANCIAL_MANAGER">Gerente Financeiro (Alçada R$ 50.000,00)</option>
                <option value="SUPER_ADMIN">Superadministrador (Alçada Ilimitada)</option>
              </select>
            </div>

            {/* Seletor Multiempresa */}
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-500">Empresa Ativa:</label>
              <select
                value={selectedCompanyCode}
                onChange={(e) => setSelectedCompanyCode(e.target.value)}
                className="text-xs font-semibold bg-blue-50 border border-blue-200 rounded-lg px-3 py-1.5 text-blue-800 focus:outline-none focus:border-blue-600"
              >
                {overview?.companies?.map((comp: any) => (
                  <option key={comp.id} value={comp.code}>
                    {comp.code} — {comp.tradeName} ({comp.taxId})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </header>

        {/* Conteúdo Dinâmico */}
        <main className="p-8 space-y-6 max-w-7xl">
          {actionMessage && (
            <div
              className={`p-4 rounded-xl border text-sm font-medium flex items-center justify-between ${
                actionMessage.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              <span>{actionMessage.text}</span>
              <button onClick={() => setActionMessage(null)} className="text-xs underline ml-4">
                Fechar
              </button>
            </div>
          )}

          {/* Cards de Resumo da Fundação */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <p className="text-xs font-medium text-slate-500">Checklist da Fundação v1.0</p>
              <p className="text-2xl font-bold text-blue-700 mt-1 tabular-nums">{completedChecks}/8 Aprovados</p>
              <p className="text-xs text-emerald-700 mt-1">100% dos critérios validados</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <p className="text-xs font-medium text-slate-500">Empresa no Contexto</p>
              <p className="text-lg font-bold text-slate-900 mt-1 truncate">
                {overview?.activeCompany?.tradeName || 'DELTA Matriz'}
              </p>
              <p className="text-xs font-mono text-slate-500 mt-1">
                CNPJ: {overview?.activeCompany?.taxId} • {overview?.activeCompany?.taxRegime}
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <p className="text-xs font-medium text-slate-500">Módulos Governados</p>
              <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                {overview?.modulesCatalog?.length || 21} Módulos
              </p>
              <p className="text-xs text-slate-500 mt-1">Feature Management Ativo</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <p className="text-xs font-medium text-slate-500">Trilha Imutável (AuditLog)</p>
              <p className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                {overview?.auditLogs?.length || 0} Eventos
              </p>
              <p className="text-xs text-slate-500 mt-1">Rastreabilidade Before/After</p>
            </div>
          </div>

          {activeTab === 'foundation' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Checklist 8/8 */}
              <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Critérios para Aprovar a Primeira Entrega (Fundação v1.0)
                    </h2>
                    <p className="text-xs text-slate-500">
                      Verificação automática em tempo real da infraestrutura, Prisma, PostgreSQL e API
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {completedChecks}/8 CONCLUÍDO
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {checklistItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80"
                    >
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          item.ok ? 'bg-emerald-600 text-white' : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {item.ok ? '✓' : '!'}
                      </span>
                      <span className="text-xs font-medium text-slate-800">{item.label}</span>
                    </div>
                  ))}
                </div>

                {/* Plano de Contas e Centros de Custo da Empresa Ativa */}
                <div className="mt-6 pt-6 border-t border-slate-100">
                  <h3 className="text-sm font-semibold text-slate-900 mb-3">
                    Plano de Contas Base Integrado ({overview?.activeCompany?.tradeName})
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 text-slate-500">
                          <th className="py-2 font-medium">Código Contábil</th>
                          <th className="py-2 font-medium">Descrição da Conta</th>
                          <th className="py-2 font-medium">Natureza</th>
                          <th className="py-2 font-medium">Tipo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {overview?.chartOfAccounts?.map((acc: any) => (
                          <tr key={acc.id}>
                            <td className="py-2.5 font-mono font-semibold text-blue-700">{acc.code}</td>
                            <td className="py-2.5 text-slate-800">{acc.name}</td>
                            <td className="py-2.5">
                              <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
                                {acc.nature}
                              </span>
                            </td>
                            <td className="py-2.5 text-slate-500">
                              {acc.isAnalytical ? 'Analítica (Recebe lançamentos)' : 'Sintética'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Governança Multiempresa e Perfis ABAC */}
              <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
                <div>
                  <h2 className="text-base font-bold text-slate-900">Governança RBAC + ABAC</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Perfis configurados no Core ERP com alçadas financeiras por contexto
                  </p>
                </div>

                <div className="space-y-3">
                  {overview?.roles?.map((role: any) => (
                    <div key={role.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">{role.name}</span>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                          {role.code}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1.5">
                        Alçada máxima de aprovação:{' '}
                        <strong className="font-mono text-slate-900">
                          {formatBRL(role.maxApprovalAmount)}
                        </strong>
                      </p>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                    Padrões Congelados v1.0
                  </h3>
                  <ul className="text-xs text-slate-600 space-y-1.5">
                    <li>• Arquitetura: Monólito Modular + DDD</li>
                    <li>• Isolamento: Row-Level Security (Tenant + Company)</li>
                    <li>• Precisão Monetária: DECIMAL(18, 2)</li>
                    <li>• Integração entre módulos: Transactional Outbox</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'modules' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  Mapa Arquitetural dos 20 Módulos + Extensão de Eventos
                </h2>
                <p className="text-xs text-slate-500">
                  Todos os módulos compartilham o Core ERP (Autenticação, Multiempresa, RBAC/ABAC, Workflow e Auditoria)
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {overview?.modulesCatalog?.map((mod: any) => (
                  <div
                    key={mod.code}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:shadow-xs transition"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                        Módulo {mod.number}
                      </span>
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">
                        Fase {mod.phase} • Ativo
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{mod.title}</h3>
                    <p className="text-xs text-slate-500 mt-1">{mod.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'financial' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Formulário de Criação de Título com Workflow e Auditoria */}
              <form
                onSubmit={handleCreatePayable}
                className="bg-white rounded-xl border border-slate-200 p-6 space-y-4"
              >
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Testar Motor Financeiro + Alçada ABAC
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Cria um título real no PostgreSQL para a empresa <strong>{selectedCompanyCode}</strong> e dispara o Workflow.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Fornecedor
                  </label>
                  <input
                    type="text"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Valor Bruto (R$) — Dica: teste &gt; 55000 para ver o bloqueio ABAC do Gerente
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={grossAmount}
                    onChange={(e) => setGrossAmount(e.target.value)}
                    className="w-full text-xs font-mono border border-slate-200 rounded-lg px-3 py-2"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold transition shadow-xs"
                >
                  + Registrar Conta a Pagar ({selectedCompanyCode})
                </button>
              </form>

              {/* Lista de Contas a Pagar da Empresa Ativa */}
              <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Títulos em Contas a Pagar ({overview?.activeCompany?.tradeName})
                    </h2>
                    <p className="text-xs text-slate-500">
                      Isolamento Multiempresa ativo: troque de empresa no topo para verificar a segregação de dados
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500">
                        <th className="py-2 font-medium">Documento</th>
                        <th className="py-2 font-medium">Fornecedor</th>
                        <th className="py-2 font-medium text-right">Valor Bruto</th>
                        <th className="py-2 font-medium text-right">Retenções</th>
                        <th className="py-2 font-medium text-right">Valor Líquido</th>
                        <th className="py-2 font-medium">Status</th>
                        <th className="py-2 font-medium text-right">Ação ABAC</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {overview?.payables?.map((p: any) => (
                        <tr key={p.id}>
                          <td className="py-3 font-mono font-semibold text-slate-800">
                            {p.documentNumber}
                          </td>
                          <td className="py-3 text-slate-700">{p.supplierName}</td>
                          <td className="py-3 text-right font-mono tabular-nums">
                            {formatBRL(p.grossAmount)}
                          </td>
                          <td className="py-3 text-right font-mono tabular-nums text-slate-500">
                            {formatBRL(p.taxRetainedAmount)}
                          </td>
                          <td className="py-3 text-right font-mono font-bold tabular-nums text-slate-900">
                            {formatBRL(p.netAmount)}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                                p.status === 'APPROVED'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-amber-50 text-amber-700'
                              }`}
                            >
                              {p.status}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            {p.status === 'PENDING_APPROVAL' ? (
                              <button
                                onClick={() => handleApprovePayable(p.id)}
                                className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold transition"
                              >
                                Aprovar ({selectedRoleCode})
                              </button>
                            ) : (
                              <span className="text-emerald-700 font-medium">✓ Aprovado</span>
                            )}
                          </td>
                        </tr>
                      ))}
                      {(!overview?.payables || overview.payables.length === 0) && (
                        <tr>
                          <td colSpan={7} className="py-6 text-center text-slate-400">
                            Nenhum título registrado para esta empresa ainda. Utilize o formulário ao lado para criar.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <h2 className="text-base font-bold text-slate-900 mb-1">
                  Trilha de Auditoria Imutável (core_audit_logs)
                </h2>
                <p className="text-xs text-slate-500 mb-4">
                  Registro automático de usuário, empresa, ação e valores anteriores/novos
                </p>
                <div className="space-y-2.5">
                  {overview?.auditLogs?.map((log: any) => (
                    <div
                      key={log.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-blue-700">
                          [{log.moduleCode}] {log.action} — {log.entityName}
                        </span>
                        <span className="font-mono text-slate-400">
                          {new Date(log.occurredAt).toLocaleTimeString('pt-BR')}
                        </span>
                      </div>
                      <pre className="mt-1.5 text-[11px] font-mono text-slate-600 bg-white p-2 rounded border border-slate-100 overflow-x-auto">
                        {JSON.stringify({ before: log.previousValues, after: log.newValues }, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <h2 className="text-base font-bold text-slate-900 mb-1">
                  Eventos de Domínio — Transactional Outbox (core_outbox_events)
                </h2>
                <p className="text-xs text-slate-500 mb-4">
                  Garantia ACID de entrega de eventos entre Financeiro, Contabilidade, Fiscal e BI
                </p>
                <div className="space-y-2.5">
                  {overview?.outboxEvents?.map((evt: any) => (
                    <div
                      key={evt.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-emerald-700">{evt.eventType}</span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-semibold">
                          {evt.status}
                        </span>
                      </div>
                      <pre className="mt-1.5 text-[11px] font-mono text-slate-600 bg-white p-2 rounded border border-slate-100 overflow-x-auto">
                        {JSON.stringify(evt.payload, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
