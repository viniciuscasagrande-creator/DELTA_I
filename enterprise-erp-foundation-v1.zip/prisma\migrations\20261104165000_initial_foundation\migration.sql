-- CreateEnum
CREATE TYPE "ModuleCode" AS ENUM ('DASHBOARD', 'FINANCIAL', 'ACCOUNTING', 'FISCAL', 'HR', 'CRM', 'PURCHASING', 'INVENTORY', 'ASSETS', 'SALES', 'PAYMENTS', 'CONTRACTS', 'SAC', 'MARKETING', 'ANALYTICS', 'DOCUMENTS', 'WORKFLOW', 'EXTERNAL_PORTAL', 'ADMINISTRATION', 'INTEGRATIONS', 'EVENTS');

-- CreateEnum
CREATE TYPE "UserType" AS ENUM ('INTERNAL', 'EXTERNAL_CLIENT', 'EXTERNAL_SUPPLIER', 'EXTERNAL_PARTNER', 'EXTERNAL_PRODUCER');

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('ACTIVE', 'PENDING_MFA', 'SUSPENDED', 'INACTIVE');

-- CreateEnum
CREATE TYPE "FinancialTitleStatus" AS ENUM ('DRAFT', 'PENDING_APPROVAL', 'APPROVED', 'PARTIALLY_PAID', 'PAID', 'CANCELLED', 'REVERSED');

-- CreateEnum
CREATE TYPE "TransactionType" AS ENUM ('CREDIT', 'DEBIT', 'TRANSFER_IN', 'TRANSFER_OUT', 'FEE_DEDUCTION', 'REVERSAL');

-- CreateEnum
CREATE TYPE "ReconciliationStatus" AS ENUM ('PENDING', 'MATCHED_AUTOMATIC', 'MATCHED_MANUAL', 'DIVERGENT');

-- CreateEnum
CREATE TYPE "AccountNature" AS ENUM ('ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE');

-- CreateEnum
CREATE TYPE "JournalEntryStatus" AS ENUM ('DRAFT', 'POSTED', 'REVERSED');

-- CreateEnum
CREATE TYPE "WorkflowStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "OutboxStatus" AS ENUM ('PENDING', 'PROCESSING', 'PUBLISHED', 'FAILED');

-- CreateEnum
CREATE TYPE "EventStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ON_SALE', 'FINISHED', 'SETTLED', 'CANCELLED');

-- CreateTable
CREATE TABLE "core_tenants" (
    "id" UUID NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "slug" VARCHAR(80) NOT NULL,
    "planTier" VARCHAR(40) NOT NULL DEFAULT 'ENTERPRISE',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_tenants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_companies" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "legalName" VARCHAR(200) NOT NULL,
    "tradeName" VARCHAR(150) NOT NULL,
    "taxId" VARCHAR(20) NOT NULL,
    "stateRegistration" VARCHAR(30),
    "municipalReg" VARCHAR(30),
    "taxRegime" VARCHAR(40) NOT NULL DEFAULT 'LUCRO_REAL',
    "baseCurrency" VARCHAR(3) NOT NULL DEFAULT 'BRL',
    "isHeadquarters" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_companies_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_branches" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "taxId" VARCHAR(20),
    "city" VARCHAR(100),
    "state" VARCHAR(2),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_branches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_departments" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "name" VARCHAR(120) NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_departments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_cost_centers" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(30) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "parentId" UUID,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_cost_centers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_users" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "email" VARCHAR(180) NOT NULL,
    "passwordHash" VARCHAR(255) NOT NULL,
    "fullName" VARCHAR(150) NOT NULL,
    "userType" "UserType" NOT NULL DEFAULT 'INTERNAL',
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "mfaEnabled" BOOLEAN NOT NULL DEFAULT false,
    "mfaSecretEncrypted" VARCHAR(255),
    "externalEntityId" UUID,
    "lastLoginAt" TIMESTAMP(3),
    "lgpdConsentAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_roles" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "code" VARCHAR(60) NOT NULL,
    "name" VARCHAR(120) NOT NULL,
    "description" VARCHAR(255),
    "isSystemRole" BOOLEAN NOT NULL DEFAULT false,
    "maxApprovalAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_permissions" (
    "id" UUID NOT NULL,
    "moduleCode" "ModuleCode" NOT NULL,
    "code" VARCHAR(100) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "description" VARCHAR(255),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "core_permissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_role_permissions" (
    "id" UUID NOT NULL,
    "roleId" UUID NOT NULL,
    "permissionId" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "core_role_permissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_user_company_access" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "userId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "roleId" UUID NOT NULL,
    "allowedCostCenterIds" TEXT[],
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_user_company_access_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_tenant_module_subscriptions" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID,
    "moduleCode" "ModuleCode" NOT NULL,
    "isEnabled" BOOLEAN NOT NULL DEFAULT true,
    "activatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "configJson" JSONB,

    CONSTRAINT "core_tenant_module_subscriptions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_audit_logs" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID,
    "userId" UUID,
    "moduleCode" "ModuleCode" NOT NULL,
    "entityName" VARCHAR(100) NOT NULL,
    "entityId" VARCHAR(100) NOT NULL,
    "action" VARCHAR(60) NOT NULL,
    "previousValues" JSONB,
    "newValues" JSONB,
    "ipAddress" VARCHAR(45),
    "userAgent" VARCHAR(255),
    "requestId" VARCHAR(100),
    "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "core_audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_workflow_instances" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "moduleCode" "ModuleCode" NOT NULL,
    "entityType" VARCHAR(80) NOT NULL,
    "entityId" UUID NOT NULL,
    "referenceAmount" DECIMAL(18,2) NOT NULL,
    "status" "WorkflowStatus" NOT NULL DEFAULT 'PENDING',
    "requestedById" UUID NOT NULL,
    "decidedById" UUID,
    "decisionNotes" VARCHAR(500),
    "decidedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "core_workflow_instances_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "core_outbox_events" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID,
    "aggregateType" VARCHAR(100) NOT NULL,
    "aggregateId" VARCHAR(100) NOT NULL,
    "eventType" VARCHAR(120) NOT NULL,
    "payload" JSONB NOT NULL,
    "status" "OutboxStatus" NOT NULL DEFAULT 'PENDING',
    "retryCount" INTEGER NOT NULL DEFAULT 0,
    "errorMessage" TEXT,
    "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "processedAt" TIMESTAMP(3),

    CONSTRAINT "core_outbox_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "fin_bank_accounts" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(30) NOT NULL,
    "name" VARCHAR(120) NOT NULL,
    "bankCode" VARCHAR(10) NOT NULL,
    "agencyNumber" VARCHAR(20) NOT NULL,
    "accountNumber" VARCHAR(30) NOT NULL,
    "pixKey" VARCHAR(120),
    "initialBalance" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "currentBalance" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "fin_bank_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "fin_categories" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(30) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "nature" "AccountNature" NOT NULL,
    "chartOfAccountId" UUID,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "fin_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "fin_accounts_payable" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "branchId" UUID,
    "categoryId" UUID NOT NULL,
    "costCenterId" UUID,
    "supplierName" VARCHAR(180) NOT NULL,
    "supplierTaxId" VARCHAR(20) NOT NULL,
    "documentNumber" VARCHAR(60) NOT NULL,
    "description" VARCHAR(255) NOT NULL,
    "originModule" "ModuleCode" NOT NULL DEFAULT 'FINANCIAL',
    "originReferenceId" UUID,
    "issueDate" DATE NOT NULL,
    "dueDate" DATE NOT NULL,
    "competenceDate" DATE NOT NULL,
    "grossAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "interestAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxRetainedAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "netAmount" DECIMAL(18,2) NOT NULL,
    "paidAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "status" "FinancialTitleStatus" NOT NULL DEFAULT 'PENDING_APPROVAL',
    "approvedById" UUID,
    "approvedAt" TIMESTAMP(3),
    "idempotencyKey" VARCHAR(100) NOT NULL,
    "createdById" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "fin_accounts_payable_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "fin_accounts_receivable" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "branchId" UUID,
    "categoryId" UUID NOT NULL,
    "costCenterId" UUID,
    "customerName" VARCHAR(180) NOT NULL,
    "customerTaxId" VARCHAR(20) NOT NULL,
    "documentNumber" VARCHAR(60) NOT NULL,
    "description" VARCHAR(255) NOT NULL,
    "originModule" "ModuleCode" NOT NULL DEFAULT 'FINANCIAL',
    "originReferenceId" UUID,
    "issueDate" DATE NOT NULL,
    "dueDate" DATE NOT NULL,
    "competenceDate" DATE NOT NULL,
    "grossAmount" DECIMAL(18,2) NOT NULL,
    "acquirerFeeAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "netAmount" DECIMAL(18,2) NOT NULL,
    "receivedAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "status" "FinancialTitleStatus" NOT NULL DEFAULT 'APPROVED',
    "idempotencyKey" VARCHAR(100) NOT NULL,
    "createdById" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "fin_accounts_receivable_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "fin_transactions" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "bankAccountId" UUID NOT NULL,
    "payableId" UUID,
    "receivableId" UUID,
    "type" "TransactionType" NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paymentMethod" VARCHAR(40) NOT NULL,
    "externalBankRef" VARCHAR(120),
    "reconciliationStatus" "ReconciliationStatus" NOT NULL DEFAULT 'PENDING',
    "reconciledAt" TIMESTAMP(3),
    "notes" VARCHAR(255),
    "idempotencyKey" VARCHAR(100) NOT NULL,
    "createdById" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "fin_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "acc_chart_of_accounts" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "nature" "AccountNature" NOT NULL,
    "isAnalytical" BOOLEAN NOT NULL DEFAULT true,
    "parentId" UUID,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "acc_chart_of_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "acc_journal_entries" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "entryNumber" INTEGER NOT NULL,
    "competenceDate" DATE NOT NULL,
    "postingDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "description" VARCHAR(255) NOT NULL,
    "originModule" "ModuleCode" NOT NULL,
    "originReferenceId" UUID,
    "totalDebit" DECIMAL(18,2) NOT NULL,
    "totalCredit" DECIMAL(18,2) NOT NULL,
    "status" "JournalEntryStatus" NOT NULL DEFAULT 'POSTED',
    "reversedEntryId" UUID,
    "idempotencyKey" VARCHAR(100) NOT NULL,
    "createdById" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "acc_journal_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "acc_journal_entry_lines" (
    "id" UUID NOT NULL,
    "journalEntryId" UUID NOT NULL,
    "chartOfAccountId" UUID NOT NULL,
    "costCenterId" UUID,
    "debitAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "creditAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "memo" VARCHAR(255),

    CONSTRAINT "acc_journal_entry_lines_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evt_producers" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "legalName" VARCHAR(200) NOT NULL,
    "tradeName" VARCHAR(150) NOT NULL,
    "taxId" VARCHAR(20) NOT NULL,
    "pixKeyForPayout" VARCHAR(120) NOT NULL,
    "defaultFeePct" DECIMAL(10,4) NOT NULL DEFAULT 10.0000,
    "advanceFeePct" DECIMAL(10,4) NOT NULL DEFAULT 2.5000,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "evt_producers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evt_events" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "producerId" UUID NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "title" VARCHAR(180) NOT NULL,
    "venueName" VARCHAR(150) NOT NULL,
    "city" VARCHAR(100) NOT NULL,
    "state" VARCHAR(2) NOT NULL,
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3) NOT NULL,
    "serviceFeePct" DECIMAL(10,4) NOT NULL,
    "status" "EventStatus" NOT NULL DEFAULT 'DRAFT',
    "grossTicketSales" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalServiceFees" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalAcquirerFees" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalChargebacks" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalAdvanced" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalPaidOut" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "evt_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evt_ticket_batches" (
    "id" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "name" VARCHAR(120) NOT NULL,
    "faceValue" DECIMAL(18,2) NOT NULL,
    "serviceFee" DECIMAL(18,2) NOT NULL,
    "totalQuota" INTEGER NOT NULL,
    "soldQuantity" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "evt_ticket_batches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evt_producer_settlements" (
    "id" UUID NOT NULL,
    "tenantId" UUID NOT NULL,
    "companyId" UUID NOT NULL,
    "eventId" UUID NOT NULL,
    "producerId" UUID NOT NULL,
    "isAdvancePayout" BOOLEAN NOT NULL DEFAULT false,
    "requestedAmount" DECIMAL(18,2) NOT NULL,
    "advanceFeeAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "netPayoutAmount" DECIMAL(18,2) NOT NULL,
    "status" "WorkflowStatus" NOT NULL DEFAULT 'PENDING',
    "payableId" UUID,
    "requestedById" UUID NOT NULL,
    "approvedById" UUID,
    "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "settledAt" TIMESTAMP(3),

    CONSTRAINT "evt_producer_settlements_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "core_tenants_slug_key" ON "core_tenants"("slug");

-- CreateIndex
CREATE INDEX "core_companies_tenantId_idx" ON "core_companies"("tenantId");

-- CreateIndex
CREATE UNIQUE INDEX "core_companies_tenantId_taxId_key" ON "core_companies"("tenantId", "taxId");

-- CreateIndex
CREATE UNIQUE INDEX "core_companies_tenantId_code_key" ON "core_companies"("tenantId", "code");

-- CreateIndex
CREATE INDEX "core_branches_tenantId_companyId_idx" ON "core_branches"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "core_branches_companyId_code_key" ON "core_branches"("companyId", "code");

-- CreateIndex
CREATE INDEX "core_departments_tenantId_companyId_idx" ON "core_departments"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "core_departments_companyId_code_key" ON "core_departments"("companyId", "code");

-- CreateIndex
CREATE INDEX "core_cost_centers_tenantId_companyId_idx" ON "core_cost_centers"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "core_cost_centers_companyId_code_key" ON "core_cost_centers"("companyId", "code");

-- CreateIndex
CREATE INDEX "core_users_tenantId_userType_idx" ON "core_users"("tenantId", "userType");

-- CreateIndex
CREATE UNIQUE INDEX "core_users_tenantId_email_key" ON "core_users"("tenantId", "email");

-- CreateIndex
CREATE INDEX "core_roles_tenantId_idx" ON "core_roles"("tenantId");

-- CreateIndex
CREATE UNIQUE INDEX "core_roles_tenantId_code_key" ON "core_roles"("tenantId", "code");

-- CreateIndex
CREATE UNIQUE INDEX "core_permissions_code_key" ON "core_permissions"("code");

-- CreateIndex
CREATE INDEX "core_permissions_moduleCode_idx" ON "core_permissions"("moduleCode");

-- CreateIndex
CREATE UNIQUE INDEX "core_role_permissions_roleId_permissionId_key" ON "core_role_permissions"("roleId", "permissionId");

-- CreateIndex
CREATE INDEX "core_user_company_access_tenantId_companyId_idx" ON "core_user_company_access"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "core_user_company_access_userId_companyId_roleId_key" ON "core_user_company_access"("userId", "companyId", "roleId");

-- CreateIndex
CREATE INDEX "core_tenant_module_subscriptions_tenantId_isEnabled_idx" ON "core_tenant_module_subscriptions"("tenantId", "isEnabled");

-- CreateIndex
CREATE UNIQUE INDEX "core_tenant_module_subscriptions_tenantId_companyId_moduleC_key" ON "core_tenant_module_subscriptions"("tenantId", "companyId", "moduleCode");

-- CreateIndex
CREATE INDEX "core_audit_logs_tenantId_companyId_moduleCode_occurredAt_idx" ON "core_audit_logs"("tenantId", "companyId", "moduleCode", "occurredAt");

-- CreateIndex
CREATE INDEX "core_audit_logs_tenantId_entityName_entityId_idx" ON "core_audit_logs"("tenantId", "entityName", "entityId");

-- CreateIndex
CREATE INDEX "core_workflow_instances_tenantId_companyId_status_idx" ON "core_workflow_instances"("tenantId", "companyId", "status");

-- CreateIndex
CREATE INDEX "core_workflow_instances_entityType_entityId_idx" ON "core_workflow_instances"("entityType", "entityId");

-- CreateIndex
CREATE INDEX "core_outbox_events_status_occurredAt_idx" ON "core_outbox_events"("status", "occurredAt");

-- CreateIndex
CREATE INDEX "core_outbox_events_tenantId_eventType_idx" ON "core_outbox_events"("tenantId", "eventType");

-- CreateIndex
CREATE INDEX "fin_bank_accounts_tenantId_companyId_idx" ON "fin_bank_accounts"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "fin_bank_accounts_companyId_code_key" ON "fin_bank_accounts"("companyId", "code");

-- CreateIndex
CREATE INDEX "fin_categories_tenantId_companyId_idx" ON "fin_categories"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "fin_categories_companyId_code_key" ON "fin_categories"("companyId", "code");

-- CreateIndex
CREATE INDEX "fin_accounts_payable_tenantId_companyId_status_dueDate_idx" ON "fin_accounts_payable"("tenantId", "companyId", "status", "dueDate");

-- CreateIndex
CREATE INDEX "fin_accounts_payable_tenantId_companyId_supplierTaxId_idx" ON "fin_accounts_payable"("tenantId", "companyId", "supplierTaxId");

-- CreateIndex
CREATE UNIQUE INDEX "fin_accounts_payable_tenantId_idempotencyKey_key" ON "fin_accounts_payable"("tenantId", "idempotencyKey");

-- CreateIndex
CREATE INDEX "fin_accounts_receivable_tenantId_companyId_status_dueDate_idx" ON "fin_accounts_receivable"("tenantId", "companyId", "status", "dueDate");

-- CreateIndex
CREATE UNIQUE INDEX "fin_accounts_receivable_tenantId_idempotencyKey_key" ON "fin_accounts_receivable"("tenantId", "idempotencyKey");

-- CreateIndex
CREATE INDEX "fin_transactions_tenantId_companyId_bankAccountId_occurredA_idx" ON "fin_transactions"("tenantId", "companyId", "bankAccountId", "occurredAt");

-- CreateIndex
CREATE UNIQUE INDEX "fin_transactions_tenantId_idempotencyKey_key" ON "fin_transactions"("tenantId", "idempotencyKey");

-- CreateIndex
CREATE INDEX "acc_chart_of_accounts_tenantId_companyId_idx" ON "acc_chart_of_accounts"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "acc_chart_of_accounts_companyId_code_key" ON "acc_chart_of_accounts"("companyId", "code");

-- CreateIndex
CREATE INDEX "acc_journal_entries_tenantId_companyId_competenceDate_idx" ON "acc_journal_entries"("tenantId", "companyId", "competenceDate");

-- CreateIndex
CREATE UNIQUE INDEX "acc_journal_entries_tenantId_idempotencyKey_key" ON "acc_journal_entries"("tenantId", "idempotencyKey");

-- CreateIndex
CREATE UNIQUE INDEX "acc_journal_entries_companyId_entryNumber_key" ON "acc_journal_entries"("companyId", "entryNumber");

-- CreateIndex
CREATE INDEX "acc_journal_entry_lines_journalEntryId_idx" ON "acc_journal_entry_lines"("journalEntryId");

-- CreateIndex
CREATE INDEX "acc_journal_entry_lines_chartOfAccountId_idx" ON "acc_journal_entry_lines"("chartOfAccountId");

-- CreateIndex
CREATE INDEX "evt_producers_tenantId_companyId_idx" ON "evt_producers"("tenantId", "companyId");

-- CreateIndex
CREATE UNIQUE INDEX "evt_producers_companyId_taxId_key" ON "evt_producers"("companyId", "taxId");

-- CreateIndex
CREATE INDEX "evt_events_tenantId_companyId_producerId_status_idx" ON "evt_events"("tenantId", "companyId", "producerId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "evt_events_companyId_code_key" ON "evt_events"("companyId", "code");

-- CreateIndex
CREATE INDEX "evt_ticket_batches_eventId_idx" ON "evt_ticket_batches"("eventId");

-- CreateIndex
CREATE INDEX "evt_producer_settlements_tenantId_companyId_eventId_status_idx" ON "evt_producer_settlements"("tenantId", "companyId", "eventId", "status");

-- AddForeignKey
ALTER TABLE "core_companies" ADD CONSTRAINT "core_companies_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_branches" ADD CONSTRAINT "core_branches_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_departments" ADD CONSTRAINT "core_departments_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_cost_centers" ADD CONSTRAINT "core_cost_centers_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_cost_centers" ADD CONSTRAINT "core_cost_centers_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "core_cost_centers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_users" ADD CONSTRAINT "core_users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_roles" ADD CONSTRAINT "core_roles_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_role_permissions" ADD CONSTRAINT "core_role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "core_roles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_role_permissions" ADD CONSTRAINT "core_role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES "core_permissions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_user_company_access" ADD CONSTRAINT "core_user_company_access_userId_fkey" FOREIGN KEY ("userId") REFERENCES "core_users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_user_company_access" ADD CONSTRAINT "core_user_company_access_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_user_company_access" ADD CONSTRAINT "core_user_company_access_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "core_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_tenant_module_subscriptions" ADD CONSTRAINT "core_tenant_module_subscriptions_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_audit_logs" ADD CONSTRAINT "core_audit_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_audit_logs" ADD CONSTRAINT "core_audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES "core_users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "core_outbox_events" ADD CONSTRAINT "core_outbox_events_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "core_tenants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_bank_accounts" ADD CONSTRAINT "fin_bank_accounts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_categories" ADD CONSTRAINT "fin_categories_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_payable" ADD CONSTRAINT "fin_accounts_payable_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_payable" ADD CONSTRAINT "fin_accounts_payable_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "fin_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_payable" ADD CONSTRAINT "fin_accounts_payable_costCenterId_fkey" FOREIGN KEY ("costCenterId") REFERENCES "core_cost_centers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_receivable" ADD CONSTRAINT "fin_accounts_receivable_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_receivable" ADD CONSTRAINT "fin_accounts_receivable_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "fin_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_accounts_receivable" ADD CONSTRAINT "fin_accounts_receivable_costCenterId_fkey" FOREIGN KEY ("costCenterId") REFERENCES "core_cost_centers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_transactions" ADD CONSTRAINT "fin_transactions_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_transactions" ADD CONSTRAINT "fin_transactions_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES "fin_bank_accounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_transactions" ADD CONSTRAINT "fin_transactions_payableId_fkey" FOREIGN KEY ("payableId") REFERENCES "fin_accounts_payable"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "fin_transactions" ADD CONSTRAINT "fin_transactions_receivableId_fkey" FOREIGN KEY ("receivableId") REFERENCES "fin_accounts_receivable"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_chart_of_accounts" ADD CONSTRAINT "acc_chart_of_accounts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_chart_of_accounts" ADD CONSTRAINT "acc_chart_of_accounts_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "acc_chart_of_accounts"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_journal_entries" ADD CONSTRAINT "acc_journal_entries_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_journal_entry_lines" ADD CONSTRAINT "acc_journal_entry_lines_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES "acc_journal_entries"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_journal_entry_lines" ADD CONSTRAINT "acc_journal_entry_lines_chartOfAccountId_fkey" FOREIGN KEY ("chartOfAccountId") REFERENCES "acc_chart_of_accounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "acc_journal_entry_lines" ADD CONSTRAINT "acc_journal_entry_lines_costCenterId_fkey" FOREIGN KEY ("costCenterId") REFERENCES "core_cost_centers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_producers" ADD CONSTRAINT "evt_producers_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_events" ADD CONSTRAINT "evt_events_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "core_companies"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_events" ADD CONSTRAINT "evt_events_producerId_fkey" FOREIGN KEY ("producerId") REFERENCES "evt_producers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_ticket_batches" ADD CONSTRAINT "evt_ticket_batches_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "evt_events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_producer_settlements" ADD CONSTRAINT "evt_producer_settlements_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "evt_events"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evt_producer_settlements" ADD CONSTRAINT "evt_producer_settlements_producerId_fkey" FOREIGN KEY ("producerId") REFERENCES "evt_producers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

