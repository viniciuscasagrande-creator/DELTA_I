import 'dotenv/config';
import { ModuleCode, UserType, AccountNature } from '@prisma/client';
import { PrismaService } from '../../apps/api/src/infrastructure/database/prisma.service';

const prisma = new PrismaService();

async function main() {
  console.log('🌱 Iniciando seed da fundação DELTA ERP Enterprise...');

  // 1. Organização (Tenant) Principal
  const tenant = await prisma.tenant.upsert({
    where: { slug: 'delta-holding' },
    update: {},
    create: {
      name: 'DELTA Holding Empresarial S.A.',
      slug: 'delta-holding',
      planTier: 'ENTERPRISE',
    },
  });

  // 2. Duas Empresas no mesmo Grupo (Matriz Operacional + Operadora de Eventos & Pagamentos)
  const hqCompany = await prisma.company.upsert({
    where: {
      tenantId_code: { tenantId: tenant.id, code: 'EMP-01' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      code: 'EMP-01',
      legalName: 'DELTA Tecnologia e Gestão Corporativa Ltda',
      tradeName: 'DELTA Matriz',
      taxId: '12.345.678/0001-90',
      taxRegime: 'LUCRO_REAL',
      isHeadquarters: true,
    },
  });

  const eventsCompany = await prisma.company.upsert({
    where: {
      tenantId_code: { tenantId: tenant.id, code: 'EMP-02' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      code: 'EMP-02',
      legalName: 'DELTA Live Events & Ticketing S.A.',
      tradeName: 'DELTA Eventos & Pagamentos',
      taxId: '98.765.432/0001-10',
      taxRegime: 'LUCRO_PRESUMIDO',
      isHeadquarters: false,
    },
  });

  // 3. Ativação de todos os 20 módulos + Extensão de Eventos
  for (const mod of Object.values(ModuleCode)) {
    await prisma.tenantModuleSubscription.upsert({
      where: {
        tenantId_companyId_moduleCode: {
          tenantId: tenant.id,
          companyId: hqCompany.id,
          moduleCode: mod,
        },
      },
      update: { isEnabled: true },
      create: {
        tenantId: tenant.id,
        companyId: hqCompany.id,
        moduleCode: mod,
        isEnabled: true,
      },
    });
  }

  // 4. Plano de Contas Base (Módulo 03 — Contabilidade)
  await prisma.chartOfAccount.upsert({
    where: {
      companyId_code: { companyId: hqCompany.id, code: '1.01.01.001' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      companyId: hqCompany.id,
      code: '1.01.01.001',
      name: 'Bancos Conta Movimento — Itaú Corporate',
      nature: AccountNature.ASSET,
      isAnalytical: true,
    },
  });

  await prisma.chartOfAccount.upsert({
    where: {
      companyId_code: { companyId: hqCompany.id, code: '2.01.03.001' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      companyId: hqCompany.id,
      code: '2.01.03.001',
      name: 'Recursos de Produtores a Repassar (Custódia Eventos)',
      nature: AccountNature.LIABILITY,
      isAnalytical: true,
    },
  });

  // 5. Perfis RBAC + ABAC (Alçadas Financeiras)
  const superAdminRole = await prisma.role.upsert({
    where: {
      tenantId_code: { tenantId: tenant.id, code: 'SUPER_ADMIN' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      code: 'SUPER_ADMIN',
      name: 'Superadministrador Global',
      isSystemRole: true,
      maxApprovalAmount: 999999999.99,
    },
  });

  const financialManagerRole = await prisma.role.upsert({
    where: {
      tenantId_code: { tenantId: tenant.id, code: 'FINANCIAL_MANAGER' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      code: 'FINANCIAL_MANAGER',
      name: 'Gerente Financeiro',
      isSystemRole: false,
      maxApprovalAmount: 50000.0,
    },
  });

  // 6. Usuário Interno Administrador
  const adminUser = await prisma.user.upsert({
    where: {
      tenantId_email: { tenantId: tenant.id, email: 'admin@deltaerp.com.br' },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      email: 'admin@deltaerp.com.br',
      passwordHash: '$2b$12$EXAMPLE_HASH_FOR_DEV_ONLY',
      fullName: 'Diretoria Executiva DELTA',
      userType: UserType.INTERNAL,
      mfaEnabled: true,
    },
  });

  await prisma.userCompanyAccess.upsert({
    where: {
      userId_companyId_roleId: {
        userId: adminUser.id,
        companyId: hqCompany.id,
        roleId: superAdminRole.id,
      },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      userId: adminUser.id,
      companyId: hqCompany.id,
      roleId: superAdminRole.id,
      allowedCostCenterIds: [],
    },
  });

  await prisma.userCompanyAccess.upsert({
    where: {
      userId_companyId_roleId: {
        userId: adminUser.id,
        companyId: eventsCompany.id,
        roleId: financialManagerRole.id,
      },
    },
    update: {},
    create: {
      tenantId: tenant.id,
      userId: adminUser.id,
      companyId: eventsCompany.id,
      roleId: financialManagerRole.id,
      allowedCostCenterIds: [],
    },
  });

  console.log('✅ Seed DELTA ERP concluído com sucesso!');
}

main()
  .catch((err) => {
    console.error('❌ Erro no seed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
