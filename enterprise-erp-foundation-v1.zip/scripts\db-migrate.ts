import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

neonConfig.webSocketConstructor = ws;

async function runMigration() {
  const migrationDir = path.resolve(process.cwd(), 'prisma/migrations/20261104165000_initial_foundation');
  const migrationFile = path.join(migrationDir, 'migration.sql');

  fs.mkdirSync(migrationDir, { recursive: true });

  console.log('📐 [1/2] Gerando script DDL a partir de prisma/schema.prisma (initial_foundation)...');
  const sqlBuffer = execSync(
    'npx prisma migrate diff --from-empty --to-schema-datamodel ./prisma/schema.prisma --script',
    { stdio: ['ignore', 'pipe', 'pipe'] }
  );
  const sqlContent = sqlBuffer.toString('utf8');
  fs.writeFileSync(migrationFile, sqlContent, 'utf8');

  const connectionString = process.env.DATABASE_URL || '';
  if (!connectionString) {
    throw new Error('DATABASE_URL não definida no arquivo .env');
  }

  console.log('🚀 [2/2] Aplicando migration "initial_foundation" no PostgreSQL...');
  const pool = new Pool({ connectionString });
  const client = await pool.connect();

  try {
    // Verifica se as tabelas da fundação já existem
    const check = await client.query(`
      SELECT to_regclass('public.core_tenants') AS exists_flag;
    `);

    if (check.rows[0]?.exists_flag) {
      console.log('ℹ️ Tabelas da migration "initial_foundation" já estão aplicadas no banco de dados.');
    } else {
      await client.query(sqlContent);
      console.log('✅ Migration "initial_foundation" aplicada com sucesso no PostgreSQL!');
    }
  } finally {
    client.release();
    await pool.end();
  }
}

runMigration().catch((err) => {
  console.error('❌ Erro ao aplicar migration:', err);
  process.exit(1);
});
